import javax.swing.JOptionPane;

public class Cliente {
   private String codigo;
   private String nome;
   private String dataNascimento;
   private String profissao;
   private Endereco endereco;

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getProfissao() {
        return profissao;
    }

    public void setProfissao(String profissao) {
        this.profissao = profissao;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }
   
   public void cadastrar(){
       this.codigo = JOptionPane.showInputDialog("Digite o código: ");
       this.nome = JOptionPane.showInputDialog("Digite o nome: ");
       this.dataNascimento = JOptionPane.showInputDialog("Digite a data (xx/xx/xxxx): ");
       this.profissao = JOptionPane.showInputDialog("Digite a profissão: ");
       this.endereco.cadastrar();
       
   }
   
    
}
