
public class Teste {

   
    public static void main(String[] args) {
        Funcionario f = new Funcionario();
        Cliente c = new Cliente();
        
        
        //f.cadastrar();
        c.cadastrar();
    }
  
}
