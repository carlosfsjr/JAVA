
package heranca;


public class Rica extends Pessoa {
    private double dinheiro;
    
    public String fazerCompras(){
        return " Como é bom ter dinheiro!";
    }
    
}
