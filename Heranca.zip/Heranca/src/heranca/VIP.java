
package heranca;


public class VIP extends Ingresso{
    private double valorAdicional;
    
    public VIP(){
        
    }
    
    public void setValorAdicional(double valorAdicional){
        this.valorAdicional = valorAdicional;
    }
    
    public double getValorAdicional(){
        return valorAdicional;
    }
    
    public double ingressoVip(){
        return valorAdicional;
    }
}
