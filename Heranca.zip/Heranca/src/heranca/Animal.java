
package heranca;


public class Animal {
    private String nome;
    private String raca;

    public Animal() {
    }
    
    public Animal(String nome){
        this.nome = nome;        
    }
    
    public String caminhar(){
        return "";
    }
    
    public void setNome(String nome)
    {
        this.nome = nome;
    }
    
    public String getNome(){
        return this.nome;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }
    
    
}
