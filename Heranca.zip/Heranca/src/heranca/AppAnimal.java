
package heranca;


public class AppAnimal {

  
    public static void main(String[] args) {
       
    }
    
}
