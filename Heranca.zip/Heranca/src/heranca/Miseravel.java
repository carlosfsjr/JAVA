
package heranca;


public class Miseravel extends Pessoa {
    public String mendigar(){
        return "Uma esmola por favor";
    }
    
}
