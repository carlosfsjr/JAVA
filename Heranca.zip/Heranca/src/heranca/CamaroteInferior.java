
package heranca;


public class CamaroteInferior {
    private String localizacao;
    
    public CamaroteInferior(){
        
    }
    
    public void setLocalizacao(String localizacao){
        this.localizacao = localizacao;
    }

    public String getLocalizacao() {
        return localizacao;
    }
    
    public String imprimirLocalizacao(){
        return "A localização é: "+localizacao;
    }
    
}
