
package heranca;


public class Gato extends Animal {
    public String miar(){
        return "miau miau";
    }
    
}
