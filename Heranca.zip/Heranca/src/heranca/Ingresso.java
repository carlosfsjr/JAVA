
package heranca;


public class Ingresso {
    private double valor;
    
    public Ingresso(){
        
    }
    
    public void setValor(double valor){
        this.valor = valor;
    }
    
    public double getValor(){
        return valor;
    }
    
    public String imprimirValor(){
        return "O valor do ingreso é: "+valor;
    }
}
