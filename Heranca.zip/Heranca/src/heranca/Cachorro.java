
package heranca;


public class Cachorro extends Animal {
    public String latir(){
        return " au au au";
    }
}
