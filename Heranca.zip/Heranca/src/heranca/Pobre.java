
package heranca;

public class Pobre extends Pessoa {
    public String trabalhar(){
        return "Vou para o trabalho";
    }
    
}
