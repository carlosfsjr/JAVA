
package heranca;


public class Normal extends Ingresso {
    public String imprimir(){
        return "Ingresso Normal";
    }
    
    public Normal(){
        
    }
}
