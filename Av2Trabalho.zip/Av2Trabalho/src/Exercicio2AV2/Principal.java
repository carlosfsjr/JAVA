
package Exercicio2AV2;

import javax.swing.JOptionPane;

public class Principal {

  
    public static void main(String[] args) {
        int a = 0, b=3, c=0, d=0, e=0;
     Televisao minhaTV = new Televisao();
     
     a = minhaTV.ligar();
     
     while(a!=0){
        minhaTV.imprimir();
     
        b = Integer.parseInt(JOptionPane.showInputDialog("Deseja trocar de canal?\nDigite 1 = Sim\nDgite 0 = Não"));
        while(b!=0){
            c = Integer.parseInt(JOptionPane.showInputDialog("Digite 1 = Aumentar Canal\nDgite 0 = Diminuir Canal"));
            if(c==1){
                minhaTV.aumentarCanal(c);
            }
            else if(c==0){
                minhaTV.diminuirCanal(c);
            } 
            b = Integer.parseInt(JOptionPane.showInputDialog("Deseja trocar de canal?\nDigite 1 = Sim\nDgite 0 = Não"));
        }
        d = Integer.parseInt(JOptionPane.showInputDialog("Deseja trocar o Volume?\nDigite 1 = Sim\nDgite 0 = Não"));
        while(d!=0){
            e = Integer.parseInt(JOptionPane.showInputDialog("Digite 1 = Aumentar Volume\nDgite 0 = Diminuir Volume"));
            if(e==1){
                minhaTV.aumentarVolume(e);
            }
            else if(e==0){
                minhaTV.diminuirVolume(e);
            } 
            d = Integer.parseInt(JOptionPane.showInputDialog("Deseja trocar o Volume?\nDigite 1 = Sim\nDgite 0 = Não"));
        }
     
     minhaTV.imprimir();
     a = Integer.parseInt(JOptionPane.showInputDialog("Deseja ligar a Tv?\nDigite 1 = Ligar\nDigite 0 = Desligar"));
     }
     JOptionPane.showMessageDialog(null, "TV desligada");
    }
    
}
