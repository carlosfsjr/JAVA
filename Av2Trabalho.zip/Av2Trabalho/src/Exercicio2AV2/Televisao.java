
package Exercicio2AV2;

import javax.swing.JOptionPane;

public class Televisao {
    private int canal=2;
    private int volume=97;

    public int getCanal() {
        return canal;
    }

    public void setCanal(int canal) {
        this.canal = canal;
    }

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        this.volume = volume;
    }
    
    public void aumentarCanal(int ac){
        if(ac==1 && this.canal>=2 && this.canal<13){
            this.canal+=1;
        }
    }
    
    public void diminuirCanal(int dc){
        if(dc==0 && this.canal>2 && this.canal<=13){
            this.canal-=1;
        }
    }
    
    public void aumentarVolume(int av){
        if(av==1 && this.volume>=0 && this.volume<100){
            this.volume+=1;
        }
    }
    
    public void diminuirVolume(int dv){
        if(dv==0 && this.volume>0 && this.volume<=100){
            this.volume-=1;
        }
    }
    public void imprimir(){
        JOptionPane.showMessageDialog(null, "Canal: "+this.canal+"\nVolume: "+this.volume);
        
    }
    
    public int ligar(){
        int a=0;
        a = Integer.parseInt(JOptionPane.showInputDialog("Deseja ligar a Tv?\nDigite 1 = Ligar\nDigite 0 = Desligar"));
        
        return a;
    }
}
