
package Exercicio01;

import javax.swing.JOptionPane;
import java.util.Scanner;


public class CadastroGeneros {

  
    public static void main(String[] args) {
        Scanner receberCodigo = new Scanner(System.in);
        Scanner receberGenero = new Scanner(System.in);
        
        Genero[] cadastrosGeneros = new Genero[1000];
        
        System.out.println("Cadastros de Gêneros de Filmes\n");
        for (int i =0; i < cadastrosGeneros.length; i++){
            Genero cadastro = new Genero();
            
            cadastro.setCodigo(Integer.parseInt(JOptionPane.showInputDialog("Código do gênero: ")));
                        
            cadastro.setDescricao(JOptionPane.showInputDialog("Descrição do gênero: "));                       
            
            //System.out.println("Código do gênero: ");
            //cadastro.setCodigo(receberCodigo.nextInt());
            
            //System.out.println("Descrição do gênero: ");
            //cadastro.setDescricao(receberGenero.next());
            
            cadastrosGeneros[i] = cadastro;
            
        }        
        
        System.out.println("\nRelatório de gêneros: ");
        for (int y = 0; y < cadastrosGeneros.length; y++){
            // JOptionPane.showMessageDialog(null,"Relatório de gêneros:\n"+"Gênero "+cadastrosGeneros[y].getCodigo()+": "+cadastrosGeneros[y].getDescricao());
            //Professor ocultei a exibição com JOptionPane, pois não conseguir exibir numa janela só.
            
            System.out.println("Gênero "+cadastrosGeneros[y].getCodigo()+": "+cadastrosGeneros[y].getDescricao());  
        }
        
    }
    
}

