
package Exercicio05;


public class Vendedor {
    private int codigo;
    private String nome;
    private byte comissao;
    private byte nrIstancias;
    
    
    
}
