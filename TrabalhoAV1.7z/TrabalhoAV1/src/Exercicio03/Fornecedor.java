package Exercicio03;


public class Fornecedor {
    private int codigo;
    private String razaoSocial;
    private String telefone;
    private String email;

    public Fornecedor() {
        this.razaoSocial = razaoSocial;
        this.telefone = telefone;
        this.email = email;
        
        
    }

    public int getCodigo() {
        return codigo;
    }

    public String getRazaoSocial() {
        return razaoSocial;
    }

    public String getTelefone() {
        return telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public void setRazaoSocial(String razaoSocial) {
        this.razaoSocial = razaoSocial;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    
}