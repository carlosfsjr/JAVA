package Exercicio03;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class CadastroFornecedores {

    public static void main(String[] args) {
        Fornecedor[] regFornecedor = new Fornecedor[500];

        for (int i = 0; i < regFornecedor.length; i++) {
            Fornecedor regF = new Fornecedor();

            regF.setCodigo(Integer.parseInt(JOptionPane.showInputDialog("Digite o código do fornecedor: ")));
            regF.setRazaoSocial(JOptionPane.showInputDialog("Digite a razão social: "));
            regF.setTelefone(JOptionPane.showInputDialog("Digite o teleforne com DDD: "));
            regF.setEmail(JOptionPane.showInputDialog("Digite o e-mail: "));

            regFornecedor[i] = regF;
        }

        System.out.println("Relatório de fornecedores:");

        for (int y = 0; y < regFornecedor.length; y++) {
            System.out.println("Fornecedor " + (y + 1) + ": " + regFornecedor[y].getRazaoSocial() + " - " + regFornecedor[y].getTelefone() + " - " +regFornecedor[y].getEmail());
        }

    }

}


