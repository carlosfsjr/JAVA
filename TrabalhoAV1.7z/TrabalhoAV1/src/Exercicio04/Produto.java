
package Exercicio04;


public class Produto {
    private int codigo;
    private String descricao;
    private int saldo;

    public Produto() {
        this.descricao = descricao;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public int getSaldo() {
        return saldo;
    }
    
    public void registrarEntrada(int quantidade){
        this.saldo += quantidade;
        
    }
    
    public void registrarSaida(int quantidade){
        this.saldo -= quantidade;
    }
    
}
