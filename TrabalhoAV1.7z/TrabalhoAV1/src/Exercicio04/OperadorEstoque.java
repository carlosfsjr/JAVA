
package Exercicio04;


public class OperadorEstoque {

  
    public static void main(String[] args) {
        String dado = null;
        int qtd;
        Produto p = new Produto();
        
        while(dado.charAt(0) == "E" || dado.charAt(0) == "S"){
            if (dado.charAt(0) == "E"){
                p.registrarEntrada(int quantidade);
            }
        }
    }

    private static void registrarEntrada(int qtd) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
