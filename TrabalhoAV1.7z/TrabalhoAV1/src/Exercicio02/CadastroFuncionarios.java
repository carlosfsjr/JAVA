
package Exercicio02;

import javax.swing.JOptionPane;
import java.util.Scanner;

public class CadastroFuncionarios {

 
    public static void main(String[] args) {
        Funcionario[] regFuncs = new Funcionario[200];
        
        for (int i = 0; i < regFuncs.length; i++){
            Funcionario func = new Funcionario();
            func.setMatricula(Integer.parseInt(JOptionPane.showInputDialog("Matrícula do funcionario "+(i+1)+": ")));
            func.setNome(JOptionPane.showInputDialog("Nome do funcionário "+(i+1)+": "));
            func.setSalario(Double.parseDouble(JOptionPane.showInputDialog("Salário do funcionário "+(i+1)+": ")));
            
            regFuncs[i] = func;
        }
        System.out.println("Relatório de funcionários:");
        for (int y = 0; y < regFuncs.length; y++){
            System.out.println("Funcionário "+(y+1)+": "+regFuncs[y].getNome()+" - "+regFuncs[y].getSalario());
            
            
        }
        
    }
    
}
