
package Exercicio02;

public class Funcionario {
    private int matricula=0;
    private String nome;
    private double salario=456;

    public Funcionario() {
        this.nome = nome;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
        
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public int getMatricula() {
        return matricula;
    }

    public String getNome() {
        return nome;
    }

    public double getSalario() {
        return salario;
    }

    @Override
    public String toString() {
        return "Funcionario{" + "matricula=" + matricula + ", nome=" + nome + ", salario=" + salario + '}';
    }
    
    
    
}

